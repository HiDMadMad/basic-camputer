#include<iostream>
using namespace std;

int main()
{
    int age;

    cout<<"Enter your age: ";
    cin>> age;

    cout<<"Senne shoma barabar hast ba: "<<age<<endl;

    return 0;

}
