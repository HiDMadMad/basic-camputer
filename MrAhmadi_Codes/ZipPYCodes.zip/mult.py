X = int(input("Enter X:"))
Y = int(input("Enter Y:"))

res = 0
i = 0

while i<X:
    res = res + Y
    i = i+1

print(res)