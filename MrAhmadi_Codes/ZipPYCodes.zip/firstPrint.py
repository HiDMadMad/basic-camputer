print("Enter your age: ")
age = input()

print("Your age is = ",age)